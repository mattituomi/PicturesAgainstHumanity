﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Billing")]
	[Tooltip("Action will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class AN_PurchaseAndConsume : FsmStateAction {

		public FsmEvent successEvent;
		public FsmEvent failEvent;

		[Tooltip("Purhase product Id")]
		public string ProductID  = "";

		public override void OnEnter() {
			Debug.Log("AN: AN_PurchaseAndConsume action started");

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			InitAndroidInventoryTask iTask = InitAndroidInventoryTask.Create();
			iTask.ActionComplete += OnInvComplete;
			iTask.ActionFailed += OnInvFailed;
			iTask.Run();
		}


		private void OnInvComplete() {
			Debug.Log("AN: OnInvComplete");
		
			if(AndroidInAppPurchaseManager.Client.Inventory.IsProductPurchased(ProductID)) {
				Debug.Log("AN: " + ProductID+ " already purchased");

				AndroidInAppPurchaseManager.ActionProductConsumed += OnProductConsumed;
				AndroidInAppPurchaseManager.Client.Consume (ProductID);

			} else {
				Debug.Log("AN: " + ProductID+ " not yet purchased");

				AndroidInAppPurchaseManager.ActionProductPurchased += OnProductPurchased;
				AndroidInAppPurchaseManager.ActionProductConsumed += OnProductConsumed;

				
				AndroidInAppPurchaseManager.Client.Purchase(ProductID);
			}
		}
		
		private void OnInvFailed() {
			OnFailed();
		}

		private void OnProductPurchased(BillingResult result) {
		
			Debug.Log ("AN: Cousume Purchased: " + result.response.ToString() + " " + result.message);

			if(result.isSuccess) {
				AndroidInAppPurchaseManager.Client.Consume (ProductID);
			} else {
				OnFailed();
			}
		}

		private void OnProductConsumed(BillingResult result) {
			Debug.Log ("AN: Cousume Responce: " + result.response.ToString() + " " + result.message);

			if(result.isSuccess) {
				OnPurchase();
			} else {
				OnFailed();
			}
		}


		private void OnPurchase() {
			Debug.Log("AN: AN_PurchaseAndConsume action Finsihed");
			Debug.Log("AN: OnPurchase Finsihed successEvent");
			AndroidInAppPurchaseManager.ActionProductPurchased -= OnProductPurchased;
			AndroidInAppPurchaseManager.ActionProductConsumed -= OnProductConsumed;

			Fsm.Event(successEvent);
			Finish();
		}

		private void OnFailed() {
			Debug.Log("AN: AN_PurchaseAndConsume action Finsihed");
			Debug.Log("AN: OnFailed Finsihed failEvent");

			AndroidInAppPurchaseManager.ActionProductPurchased -= OnProductPurchased;
			AndroidInAppPurchaseManager.ActionProductConsumed -= OnProductConsumed;

			Fsm.Event(failEvent);
			Finish();

		}
		
	}
}
