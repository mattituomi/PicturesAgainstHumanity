﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Utils")]
	public class AN_IsPackageInstalled : FsmStateAction {
				
		public FsmEvent packageFound;
		public FsmEvent packageNotFound;

		public FsmString package;

		public override void OnEnter() {

			AndroidNativeUtility.OnPackageCheckResult += OnPackageCheckResult;
			

			AndroidNativeUtility.instance.CheckIsPackageInstalled(package.Value);

		}

		private void OnPackageCheckResult (AN_PackageCheckResult res) {
			if(res.IsSucceeded) {
				Fsm.Event(packageFound);
			} else {
				Fsm.Event(packageNotFound);
			}

			Finish();

		}

	}
}


