﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_GetGameSaveByIndex : FsmStateAction {

		public FsmInt SnapshotIndex;

		public FsmEvent Loaded;
		public FsmEvent Failure;

		public FsmString Title;
		public FsmString Description;
		public FsmString CoverImageUri;
		public FsmInt LastModifiedTimestamp;
		public FsmInt TotalPlayedTime;

		public override void OnEnter() {
			if (GooglePlaySavedGamesManager.instance.AvailableGameSaves.Count > SnapshotIndex.Value) {
				GP_SnapshotMeta snapshot = GooglePlaySavedGamesManager.instance.AvailableGameSaves[SnapshotIndex.Value];

				Title.Value = snapshot.Title;
				Description.Value = snapshot.Description;
				CoverImageUri.Value = snapshot.CoverImageUrl;
				LastModifiedTimestamp.Value = (int)snapshot.LastModifiedTimestamp;
				TotalPlayedTime.Value = (int)snapshot.TotalPlayedTime;

				Fsm.Event(Loaded);
				Finish ();
			} else {
				Fsm.Event(Failure);
				Finish();
			}
		}
	}
}
